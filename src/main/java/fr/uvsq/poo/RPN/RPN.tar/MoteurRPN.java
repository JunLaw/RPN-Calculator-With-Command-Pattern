package fr.uvsq.poo.RPN;

import java.util.Stack;


public class MoteurRPN extends Interpreteur {
    Stack<Integer> stackRPN;
    MoteurRPN()
    {
        stackRPN = new Stack<Integer>();
    }

    public void regOP(int num){
       stackRPN.add(num);
    }

    public Boolean apOP(String op){
        if(stackRPN.size() < 2){
            System.out.println("not enough number in stack");
            return false;
        }
        switch(op){
            case "+":
                stackRPN.push(stackRPN.pop() + stackRPN.pop());

                break;
            case "-":
                stackRPN.push(stackRPN.pop() - stackRPN.pop());
                break;
            case "/":
                stackRPN.push(stackRPN.pop() / stackRPN.pop());
                break;
            case "*":
                stackRPN.push(stackRPN.pop() * stackRPN.pop());
                break;
            default:
                System.out.println("not an operand");
                break;
        }
    return true;
    }

    public Stack<Integer> retOP(){
        Stack<Integer> cpy = new Stack<Integer>();
        cpy = (Stack<Integer>) stackRPN.clone();

        while(!cpy.isEmpty()){
            System.out.println(cpy.pop());
        }
        return stackRPN;
    }
}
