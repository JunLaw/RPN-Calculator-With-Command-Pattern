package fr.uvsq.poo.RPN;

public class Interpreteur {

    public void undo(){
        System.out.println("undo");

    }

    public void exit(){
        System.out.println("exit");
        System.exit(0);
    }
}
