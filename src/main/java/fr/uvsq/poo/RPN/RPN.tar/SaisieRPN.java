package fr.uvsq.poo.RPN;


import java.util.Scanner;

public class SaisieRPN {
    MoteurRPN rpn;
    Scanner scan = new Scanner(System.in);
    Invoker in;

    public SaisieRPN(Invoker in){
        rpn = new MoteurRPN();
        this.in = in;
    }

    public static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch(NumberFormatException e){
            return false;
        }
    }


    public boolean read(){
        String str = new String(" ");
       while(!str.equals("")){
                str = scan.nextLine();
                if(str.equals("+") || str.equals("-") || str.equals("*") || str.equals("/") )
                {
                   if( !rpn.apOP(str) ){
                        return false;
                   }
                   rpn.retOP();
                }
                else if(SaisieRPN.isNumeric(str))
                {
                    //System.out.print(str);
                    rpn.regOP(Integer.parseInt(str));
                    rpn.retOP();

                }else{
                    if(str.equals("undo")){
                    rpn.undo();
                    rpn.retOP();
                    in.undo();

                    }else if(str.equals("exit")){
                        rpn.retOP();
                        rpn.exit();
                    }
                    else {
                   System.out.println("Not a number nor operator");
                    }
           }
                str.replace(str," ");
       }
       return true;
    }


}
