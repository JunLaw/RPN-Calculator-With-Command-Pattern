package fr.uvsq.poo.RPN;

public class CalculatriceRPN {
    public static void main(String[] args){
        SaisieRPN saisie = new SaisieRPN(new Invoker());
        boolean i = saisie.read();
        if(!i){
            System.out.println("operation unsuccessful");
        }else{
            System.out.println("operation successful");
        }

    }
}
