package fr.uvsq.poo.RPN;

public class Undo implements Command{
    private Interpreteur inter;

    public Undo(Interpreteur inter){
        this.inter = inter;
    }

    @Override
    public void execute() {
        this.inter.undo();
    }


}
