package fr.uvsq.poo.RPN;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Invoker {
    private HashMap<String,Command> commands = new HashMap<>();
    private List<Command> history = new ArrayList<Command>();

    public void register(String msgCmd,Command cmd){
        commands.put(msgCmd,cmd);
    }

    public void execute(String msgCmd){
        Command command = commands.get(msgCmd);
        if(command == null){
            throw new IllegalStateException("no command registered" + msgCmd);
        }
        this.history.add(command);
        command.execute();
    }

    public void undo(){

        history.remove(history.size());
    }

}
