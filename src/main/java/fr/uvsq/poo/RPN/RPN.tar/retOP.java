package fr.uvsq.poo.RPN;

public class retOP implements Command{
    private SaisieRPN mot;

    public retOP(SaisieRPN mot){
        this.mot = mot;
    }

    @Override
    public void execute() {
        this.mot.rpn.retOP();
    }
}
