package fr.uvsq.poo.RPN;

public class regOP implements Command {
    private SaisieRPN mot;
    private int num;
    public regOP(SaisieRPN mot,int num){
        this.mot = mot;
        this.num = num;
    }
    @Override
    public void execute() {
        this.mot.rpn.regOP(this.num);
    }
}
