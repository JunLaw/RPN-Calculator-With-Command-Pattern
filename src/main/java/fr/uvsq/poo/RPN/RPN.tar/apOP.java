package fr.uvsq.poo.RPN;

public class apOP implements Command{
    private SaisieRPN mot;
    private String str;
    public apOP(SaisieRPN mot,String str){
        this.mot = mot;
        this.str = str;
    }
    @Override
    public void execute() {
        this.mot.rpn.apOP(str);
    }
}
