package fr.uvsq.poo.RPN;



public interface Command {
    void execute();

}
